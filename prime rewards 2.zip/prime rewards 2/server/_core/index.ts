import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);

  // Twilio WhatsApp delivery status callbacks
  app.post("/api/twilio/whatsapp/status", express.urlencoded({ extended: false }), async (req, res) => {
    try {
      const { handleWhatsAppStatusCallback } = await import("../whatsapp");
      await handleWhatsAppStatusCallback(req.body as Record<string, string>);
      res.status(200).send("");
    } catch (error) {
      console.error("[WhatsApp] Status callback handler error:", error);
      res.status(500).send("");
    }
  });

  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
    import("../whatsapp").then(({ startWhatsAppRetryScheduler, isWhatsAppConfigured }) => {
      if (isWhatsAppConfigured()) {
        startWhatsAppRetryScheduler();
        console.log("[WhatsApp] Twilio integration active");
      } else {
        console.warn("[WhatsApp] Twilio env vars missing — WhatsApp notifications disabled");
      }
    });
  });
}

startServer().catch(console.error);
