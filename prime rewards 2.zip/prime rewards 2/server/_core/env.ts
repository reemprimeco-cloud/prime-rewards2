export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  twilioAccountSid: process.env.TWILIO_ACCOUNT_SID ?? "",
  twilioAuthToken: process.env.TWILIO_AUTH_TOKEN ?? "",
  twilioWhatsAppNumber:
    process.env.TWILIO_WHATSAPP_NUMBER ??
    process.env.TWILIO_WHATSAPP_FROM ??
    "",
  twilioWhatsAppTemplateSid:
    process.env.TWILIO_WHATSAPP_TEMPLATE_SID ??
    process.env.TWILIO_WHATSAPP_INVOICE_TEMPLATE_SID ??
    "",
  appBaseUrl: process.env.APP_BASE_URL ?? process.env.VITE_APP_URL ?? "",
};
