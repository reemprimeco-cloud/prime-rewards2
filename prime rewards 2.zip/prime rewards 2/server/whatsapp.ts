import twilio from "twilio";
import { and, eq, inArray, lte, or, sql } from "drizzle-orm";
import { whatsappMessages, invoices } from "../drizzle/schema";
import { ENV } from "./_core/env";
import { getCustomerById, getDb } from "./db";

const LOG_PREFIX = "[WhatsApp]";
const MAX_RETRIES = 3;
const RETRY_DELAYS_MS = [60_000, 300_000, 900_000];

export type WhatsAppEventType = "invoice_approved" | "reward_redeemed" | "welcome";

export type InvoiceApprovalWhatsAppPayload = {
  customerId: number;
  invoiceId: number;
  invoiceNumber: string;
  pointsEarned: number;
  balance: number;
  phone: string | null | undefined;
  customerName: string;
};

type SendResult = {
  success: boolean;
  messageId?: number;
  skipped?: boolean;
  reason?: string;
};

let twilioClient: ReturnType<typeof twilio> | null = null;

function log(level: "info" | "warn" | "error", message: string, data?: Record<string, unknown>) {
  const payload = data ? ` ${JSON.stringify(data)}` : "";
  const line = `${LOG_PREFIX} ${message}${payload}`;
  if (level === "error") console.error(line);
  else if (level === "warn") console.warn(line);
  else console.log(line);
}

export function isWhatsAppConfigured(): boolean {
  return Boolean(ENV.twilioAccountSid && ENV.twilioAuthToken && ENV.twilioWhatsAppNumber);
}

function getTwilioClient() {
  if (!isWhatsAppConfigured()) {
    throw new Error("Twilio WhatsApp is not configured");
  }
  if (!twilioClient) {
    twilioClient = twilio(ENV.twilioAccountSid, ENV.twilioAuthToken);
  }
  return twilioClient;
}

function normalizeFromNumber(from: string): string {
  const trimmed = from.trim();
  return trimmed.startsWith("whatsapp:") ? trimmed : `whatsapp:${trimmed.startsWith("+") ? trimmed : `+${trimmed.replace(/\D/g, "")}`}`;
}

/** Format customer phone as `whatsapp:+965XXXXXXXX` for Kuwait numbers. */
export function formatWhatsAppPhone(phone: string): string | null {
  const digits = phone.replace(/\D/g, "");
  if (!digits) return null;

  let national = digits;
  if (national.startsWith("00")) national = national.slice(2);
  if (national.startsWith("965")) national = national.slice(3);

  if (national.length !== 8) {
    log("warn", "Invalid Kuwait phone length", { phone, digits: national });
    return null;
  }

  return `whatsapp:+965${national}`;
}

function buildStatusCallbackUrl(): string | undefined {
  if (!ENV.appBaseUrl) return undefined;
  const base = ENV.appBaseUrl.replace(/\/$/, "");
  return `${base}/api/twilio/whatsapp/status`;
}

function buildTemplateVariables(payload: InvoiceApprovalWhatsAppPayload): string {
  return JSON.stringify({
    "1": payload.customerName,
    "2": payload.invoiceNumber,
    "3": String(payload.pointsEarned),
    "4": String(payload.balance),
  });
}

function buildFallbackBody(payload: InvoiceApprovalWhatsAppPayload): string {
  return (
    `Prime Rewards Update\n` +
    `Hi ${payload.customerName}, your invoice #${payload.invoiceNumber} has been approved.\n` +
    `${payload.pointsEarned} points have been added to your account.\n` +
    `Current balance: ${payload.balance} pts`
  );
}

async function findExistingMessage(invoiceId: number, eventType: WhatsAppEventType) {
  const db = await getDb();
  if (!db) return null;

  const rows = await db
    .select()
    .from(whatsappMessages)
    .where(and(eq(whatsappMessages.invoiceId, invoiceId), eq(whatsappMessages.eventType, eventType)))
    .limit(1);

  return rows[0] ?? null;
}

async function createOrGetMessageRecord(
  payload: InvoiceApprovalWhatsAppPayload,
  formattedPhone: string
): Promise<{ recordId: number; isDuplicate: boolean }> {
  const db = await getDb();
  if (!db) throw new Error("DB unavailable");

  const existing = await findExistingMessage(payload.invoiceId, "invoice_approved");
  if (existing) {
    const terminalSuccess = ["queued", "sent", "delivered", "read"].includes(existing.status);
    if (terminalSuccess) {
      log("info", "Duplicate send prevented", {
        invoiceId: payload.invoiceId,
        existingStatus: existing.status,
        messageId: existing.id,
      });
      return { recordId: existing.id, isDuplicate: true };
    }
    return { recordId: existing.id, isDuplicate: false };
  }

  try {
    const [insertResult] = await db.insert(whatsappMessages).values({
      customerId: payload.customerId,
      invoiceId: payload.invoiceId,
      eventType: "invoice_approved",
      phone: formattedPhone,
      templateSid: ENV.twilioWhatsAppTemplateSid || null,
      status: "pending",
      maxAttempts: MAX_RETRIES,
    });

    const recordId = Number(insertResult.insertId);
    return { recordId, isDuplicate: false };
  } catch (error) {
    const err = error as { code?: string };
    if (err.code === "ER_DUP_ENTRY") {
      const dup = await findExistingMessage(payload.invoiceId, "invoice_approved");
      if (dup) {
        log("info", "Duplicate send prevented (race)", { invoiceId: payload.invoiceId, messageId: dup.id });
        return { recordId: dup.id, isDuplicate: true };
      }
    }
    throw error;
  }
}

async function dispatchTwilioMessage(
  recordId: number,
  to: string,
  payload: InvoiceApprovalWhatsAppPayload
): Promise<SendResult> {
  const db = await getDb();
  if (!db) return { success: false, reason: "DB unavailable" };

  const from = normalizeFromNumber(ENV.twilioWhatsAppNumber);
  const statusCallback = buildStatusCallbackUrl();
  const useTemplate = Boolean(ENV.twilioWhatsAppTemplateSid);

  const requestPayload: Record<string, unknown> = {
    from,
    to,
    ...(useTemplate
      ? {
          contentSid: ENV.twilioWhatsAppTemplateSid,
          contentVariables: buildTemplateVariables(payload),
        }
      : { body: buildFallbackBody(payload) }),
    ...(statusCallback ? { statusCallback } : {}),
  };

  log("info", "Triggering WhatsApp send", {
    recordId,
    invoiceId: payload.invoiceId,
    customerId: payload.customerId,
    to,
    from,
    useTemplate,
    templateSid: useTemplate ? ENV.twilioWhatsAppTemplateSid : null,
  });

  log("info", "Twilio API request", {
    recordId,
    endpoint: "messages.create",
    payload: {
      ...requestPayload,
      contentVariables: requestPayload.contentVariables ?? undefined,
    },
  });

  try {
    const client = getTwilioClient();
    const message = await client.messages.create(requestPayload as Parameters<typeof client.messages.create>[0]);

    log("info", "Twilio API response", {
      recordId,
      sid: message.sid,
      status: message.status,
      errorCode: message.errorCode,
      errorMessage: message.errorMessage,
    });

    await db
      .update(whatsappMessages)
      .set({
        status: mapTwilioStatus(message.status),
        twilioMessageSid: message.sid,
        attemptCount: sql`${whatsappMessages.attemptCount} + 1`,
        sentAt: new Date(),
        errorCode: message.errorCode ? String(message.errorCode) : null,
        errorMessage: message.errorMessage ?? null,
        nextRetryAt: null,
      })
      .where(eq(whatsappMessages.id, recordId));

    return { success: true, messageId: recordId };
  } catch (error) {
    const err = error as { code?: number | string; message?: string; status?: number; moreInfo?: string };
    const errorMessage = err.message ?? String(error);
    const errorCode = err.code != null ? String(err.code) : undefined;

    log("error", "Twilio send failed", {
      recordId,
      invoiceId: payload.invoiceId,
      errorCode,
      errorMessage,
      status: err.status,
      moreInfo: err.moreInfo,
    });

    const [current] = await db.select().from(whatsappMessages).where(eq(whatsappMessages.id, recordId)).limit(1);
    const attemptCount = (current?.attemptCount ?? 0) + 1;
    const shouldRetry = attemptCount < MAX_RETRIES;

    await db
      .update(whatsappMessages)
      .set({
        status: "failed",
        attemptCount,
        errorCode: errorCode ?? null,
        errorMessage,
        nextRetryAt: shouldRetry ? new Date(Date.now() + RETRY_DELAYS_MS[attemptCount - 1]!) : null,
      })
      .where(eq(whatsappMessages.id, recordId));

    return { success: false, messageId: recordId, reason: errorMessage };
  }
}

function mapTwilioStatus(status: string): "queued" | "sent" | "delivered" | "read" | "failed" | "undelivered" {
  switch (status) {
    case "queued":
    case "accepted":
    case "scheduled":
    case "sending":
      return "queued";
    case "sent":
      return "sent";
    case "delivered":
      return "delivered";
    case "read":
      return "read";
    case "undelivered":
      return "undelivered";
    case "failed":
    case "canceled":
      return "failed";
    default:
      return "queued";
  }
}

export async function sendInvoiceApprovalWhatsApp(payload: InvoiceApprovalWhatsAppPayload): Promise<SendResult> {
  log("info", "Invoice approval WhatsApp hook", {
    invoiceId: payload.invoiceId,
    invoiceNumber: payload.invoiceNumber,
    customerId: payload.customerId,
    pointsEarned: payload.pointsEarned,
    balance: payload.balance,
  });

  if (!isWhatsAppConfigured()) {
    log("warn", "Twilio not configured — skipping send", {
      hasAccountSid: Boolean(ENV.twilioAccountSid),
      hasAuthToken: Boolean(ENV.twilioAuthToken),
      hasWhatsAppNumber: Boolean(ENV.twilioWhatsAppNumber),
    });
    return { success: false, skipped: true, reason: "Twilio not configured" };
  }

  if (!payload.phone) {
    log("warn", "Customer has no phone number — skipping WhatsApp", {
      customerId: payload.customerId,
      invoiceId: payload.invoiceId,
    });
    return { success: false, skipped: true, reason: "No phone number" };
  }

  const formattedPhone = formatWhatsAppPhone(payload.phone);
  if (!formattedPhone) {
    log("warn", "Phone formatting failed — skipping WhatsApp", {
      customerId: payload.customerId,
      invoiceId: payload.invoiceId,
      rawPhone: payload.phone,
    });
    return { success: false, skipped: true, reason: "Invalid phone format" };
  }

  const { recordId, isDuplicate } = await createOrGetMessageRecord(payload, formattedPhone);
  if (isDuplicate) {
    return { success: true, skipped: true, reason: "Already sent", messageId: recordId };
  }

  return dispatchTwilioMessage(recordId, formattedPhone, payload);
}

export async function retryFailedWhatsAppMessages(): Promise<number> {
  const db = await getDb();
  if (!db || !isWhatsAppConfigured()) return 0;

  const now = new Date();
  const retryable = await db
    .select()
    .from(whatsappMessages)
    .where(
      and(
        eq(whatsappMessages.eventType, "invoice_approved"),
        inArray(whatsappMessages.status, ["failed", "pending", "undelivered"]),
        sql`${whatsappMessages.attemptCount} < ${whatsappMessages.maxAttempts}`,
        or(sql`${whatsappMessages.nextRetryAt} IS NULL`, lte(whatsappMessages.nextRetryAt, now))
      )
    )
    .limit(20);

  let retried = 0;
  for (const message of retryable) {
    if (!message.invoiceId) continue;

    log("info", "Retrying failed WhatsApp message", {
      messageId: message.id,
      invoiceId: message.invoiceId,
      attemptCount: message.attemptCount,
      status: message.status,
    });

    const customer = await getCustomerById(message.customerId);
    if (!customer) continue;

    const [invoice] = await db
      .select()
      .from(invoices)
      .where(eq(invoices.id, message.invoiceId))
      .limit(1);
    if (!invoice) continue;

    const result = await dispatchTwilioMessage(message.id, message.phone, {
      customerId: message.customerId,
      invoiceId: message.invoiceId,
      invoiceNumber: invoice.invoiceNumber,
      pointsEarned: invoice.pointsEarned,
      balance: customer.totalPoints,
      phone: customer.phone,
      customerName: customer.fullName,
    });

    if (result.success) retried += 1;
  }

  if (retried > 0) {
    log("info", "WhatsApp retry batch complete", { retried, attempted: retryable.length });
  }

  return retried;
}

export async function handleWhatsAppStatusCallback(body: Record<string, string>): Promise<void> {
  const messageSid = body.MessageSid ?? body.SmsSid;
  const messageStatus = body.MessageStatus ?? body.SmsStatus;
  const errorCode = body.ErrorCode;
  const errorMessage = body.ErrorMessage;

  log("info", "Twilio status callback received", {
    messageSid,
    messageStatus,
    errorCode,
    errorMessage,
    to: body.To,
    from: body.From,
  });

  if (!messageSid || !messageStatus) {
    log("warn", "Status callback missing required fields", { body });
    return;
  }

  const db = await getDb();
  if (!db) return;

  const mappedStatus = mapTwilioStatus(messageStatus);
  const update: Partial<typeof whatsappMessages.$inferInsert> = {
    status: mappedStatus,
    errorCode: errorCode ?? null,
    errorMessage: errorMessage ?? null,
  };

  if (mappedStatus === "delivered" || mappedStatus === "sent") {
    update.deliveredAt = mappedStatus === "delivered" ? new Date() : undefined;
    if (mappedStatus === "sent") update.sentAt = new Date();
  }

  if (mappedStatus === "failed" || mappedStatus === "undelivered") {
    log("error", "WhatsApp delivery failed", { messageSid, errorCode, errorMessage, messageStatus });

    const [existing] = await db
      .select()
      .from(whatsappMessages)
      .where(eq(whatsappMessages.twilioMessageSid, messageSid))
      .limit(1);

    if (existing && existing.attemptCount < existing.maxAttempts) {
      update.nextRetryAt = new Date(
        Date.now() + RETRY_DELAYS_MS[Math.min(existing.attemptCount, RETRY_DELAYS_MS.length - 1)]!
      );
    }
  }

  await db.update(whatsappMessages).set(update).where(eq(whatsappMessages.twilioMessageSid, messageSid));

  log("info", "WhatsApp delivery status updated", { messageSid, status: mappedStatus });
}

export async function getWhatsAppDeliveryStats() {
  const db = await getDb();
  if (!db) {
    return {
      total: 0,
      delivered: 0,
      sent: 0,
      failed: 0,
      pending: 0,
      recent: [] as Array<typeof whatsappMessages.$inferSelect>,
    };
  }

  const all = await db.select().from(whatsappMessages).orderBy(sql`${whatsappMessages.createdAt} DESC`).limit(100);

  const countBy = (statuses: string[]) =>
    all.filter((m) => statuses.includes(m.status)).length;

  return {
    total: all.length,
    delivered: countBy(["delivered", "read"]),
    sent: countBy(["sent", "queued"]),
    failed: countBy(["failed", "undelivered"]),
    pending: countBy(["pending"]),
    recent: all.slice(0, 10),
  };
}

export async function getWhatsAppStatusForInvoices(invoiceIds: number[]) {
  const db = await getDb();
  if (!db || invoiceIds.length === 0) return {};

  const rows = await db
    .select()
    .from(whatsappMessages)
    .where(
      and(
        inArray(whatsappMessages.invoiceId, invoiceIds),
        eq(whatsappMessages.eventType, "invoice_approved")
      )
    );

  return Object.fromEntries(rows.map((row) => [row.invoiceId!, row]));
}

export function startWhatsAppRetryScheduler() {
  if (!isWhatsAppConfigured()) {
    log("warn", "Retry scheduler not started — Twilio not configured");
    return;
  }

  log("info", "Starting WhatsApp retry scheduler (every 5 minutes)");
  setInterval(() => {
    retryFailedWhatsAppMessages().catch((error) => {
      log("error", "Retry scheduler error", { error: String(error) });
    });
  }, 5 * 60 * 1000);
}
