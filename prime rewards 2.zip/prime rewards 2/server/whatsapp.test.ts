import { describe, expect, it } from "vitest";
import { formatWhatsAppPhone } from "./whatsapp";

describe("formatWhatsAppPhone", () => {
  it("formats 8-digit Kuwait local numbers", () => {
    expect(formatWhatsAppPhone("50123456")).toBe("whatsapp:+96550123456");
  });

  it("formats numbers with country code", () => {
    expect(formatWhatsAppPhone("+96550123456")).toBe("whatsapp:+96550123456");
  });

  it("formats numbers with spaces and dashes", () => {
    expect(formatWhatsAppPhone("965 5012 3456")).toBe("whatsapp:+96550123456");
  });

  it("returns null for invalid length", () => {
    expect(formatWhatsAppPhone("12345")).toBeNull();
  });

  it("returns null for empty input", () => {
    expect(formatWhatsAppPhone("")).toBeNull();
  });
});
