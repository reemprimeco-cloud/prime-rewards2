# Manus Task: Fix WhatsApp Notifications on Invoice Approval

## Problem
Customers receive points after invoice approval, but no WhatsApp message is sent. Twilio WhatsApp sender is connected. The integration was documented in INTEGRATION_GUIDE.md but never implemented in code.

## Root cause
`reviewInvoice()` in `server/db.ts` only calls `addPoints()` and `createNotification()` (in-app). There is no Twilio integration, no `server/whatsapp.ts`, and no `twilio` package.

## What to implement

### 1. Install dependency
```bash
pnpm add twilio
```

### 2. Add env vars to `server/_core/env.ts`
```typescript
twilioAccountSid: process.env.TWILIO_ACCOUNT_SID ?? "",
twilioAuthToken: process.env.TWILIO_AUTH_TOKEN ?? "",
twilioWhatsAppNumber:
  process.env.TWILIO_WHATSAPP_NUMBER ??
  process.env.TWILIO_WHATSAPP_FROM ??
  "",
twilioWhatsAppTemplateSid:
  process.env.TWILIO_WHATSAPP_TEMPLATE_SID ??
  process.env.TWILIO_WHATSAPP_INVOICE_TEMPLATE_SID ??
  "",
appBaseUrl: process.env.APP_BASE_URL ?? process.env.VITE_APP_URL ?? "",
```

### 3. Add `whatsapp_messages` table to `drizzle/schema.ts`
Track delivery status, prevent duplicates (unique on invoiceId + eventType), support retries.

### 4. Generate and apply migration
Run `pnpm db:push` or apply SQL:
```sql
CREATE TABLE `whatsapp_messages` (
  `id` int AUTO_INCREMENT NOT NULL,
  `customerId` int NOT NULL,
  `invoiceId` int,
  `eventType` enum('invoice_approved','reward_redeemed','welcome') NOT NULL,
  `phone` varchar(32) NOT NULL,
  `templateSid` varchar(64),
  `status` enum('pending','queued','sent','delivered','read','failed','undelivered') NOT NULL DEFAULT 'pending',
  `twilioMessageSid` varchar(64),
  `errorCode` varchar(32),
  `errorMessage` text,
  `attemptCount` int NOT NULL DEFAULT 0,
  `maxAttempts` int NOT NULL DEFAULT 3,
  `nextRetryAt` timestamp,
  `sentAt` timestamp,
  `deliveredAt` timestamp,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `whatsapp_messages_id` PRIMARY KEY(`id`),
  CONSTRAINT `whatsapp_messages_invoice_event_unique` UNIQUE(`invoiceId`,`eventType`)
);
```

### 5. Create `server/whatsapp.ts`
Full Twilio integration with:
- `formatWhatsAppPhone()` → `whatsapp:+965XXXXXXXX` (8-digit Kuwait numbers)
- `sendInvoiceApprovalWhatsApp()` — called after invoice approval
- Approved template via `contentSid` + `contentVariables` ({{1}} name, {{2}} invoice#, {{3}} points, {{4}} balance)
- Fallback plain `body` if no template SID configured
- Detailed console logs: `[WhatsApp]` and `[Invoice]` prefixes
- Duplicate send prevention via DB unique constraint
- Retry failed messages (3 attempts, 1min/5min/15min backoff)
- `handleWhatsAppStatusCallback()` for Twilio webhooks
- `getWhatsAppDeliveryStats()` and `getWhatsAppStatusForInvoices()` for admin
- `startWhatsAppRetryScheduler()` — every 5 minutes

### 6. Wire into `server/db.ts` → `reviewInvoice()`
After approval + points + in-app notification, trigger WhatsApp **non-blocking**:
```typescript
void import("./whatsapp").then(({ sendInvoiceApprovalWhatsApp }) =>
  sendInvoiceApprovalWhatsApp({
    customerId, invoiceId, invoiceNumber, pointsEarned,
    balance: updatedCustomer?.totalPoints ?? result.newTotal,
    phone: customer?.phone,
    customerName: customer?.fullName ?? "Customer",
  }).catch(...)
);
```
Add `whatsappStats` to `getAdminAnalytics()` return value.

### 7. Update `server/_core/index.ts`
- POST `/api/twilio/whatsapp/status` — Twilio delivery callbacks
- On server start: call `startWhatsAppRetryScheduler()` if Twilio configured

### 8. Update `server/routers.ts`
- `invoices.all` — attach `whatsapp` status per invoice
- `admin.whatsappStatus` — delivery stats query
- `admin.retryWhatsApp` — manual retry mutation

### 9. Update Admin UI
- `AdminDashboard.tsx` — WhatsApp Delivery Status panel (total/delivered/sent/failed/pending + recent log + Retry Failed button)
- `AdminInvoices.tsx` — WA status badge on approved invoices + error message display

### 10. Add secrets in Manus Settings → Secrets
| Variable | Required |
|----------|----------|
| `TWILIO_ACCOUNT_SID` | Yes |
| `TWILIO_AUTH_TOKEN` | Yes |
| `TWILIO_WHATSAPP_NUMBER` | Yes (e.g. `whatsapp:+14155238886`) |
| `TWILIO_WHATSAPP_TEMPLATE_SID` | Yes for production |
| `APP_BASE_URL` | Yes (e.g. `https://rewards.primeprint.com.kw`) |

### 11. Publish and test
1. Publish from Manus dashboard
2. Ensure test customer has phone number (8-digit Kuwait, e.g. `50123456`)
3. Approve a test invoice
4. Check logs for `[WhatsApp] Twilio API response`
5. Verify Admin Dashboard shows delivery status

## Acceptance criteria
- [ ] WhatsApp sent when admin approves invoice
- [ ] Phone formatted as `whatsapp:+965XXXXXXXX`
- [ ] Uses approved Twilio template when SID is set
- [ ] No duplicate sends for same invoice
- [ ] Failed sends retried automatically
- [ ] Delivery status visible in admin dashboard
- [ ] Invoice approval still succeeds if WhatsApp fails
